

<h1 style="color:black; font-size:40pt;">keboenkoeh.id</h1><?php /**PATH E:\~GITHUB\keboenkoeh.id\resources\views/components/application-logo.blade.php ENDPATH**/ ?>
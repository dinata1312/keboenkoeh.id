<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <form class="p-10 bg-white rounded shadow-xl" action="<?php echo e(route('add-keuangan')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <p class="text-3xl text-gray-800 font-medium pb-4">
            Tambah Transaksi
        </p>
        <div class="">
            <label class="block text-md text-gray-600" for="title">Judul</label>
            <input class="w-full px-2 py-1 text-gray-700 bg-gray-50 rounded" id="title" name="title" type="text" required="">
        </div>
        <div class="mt-2">
            <label class="block text-md text-gray-600" for="detail">Keterangan</label>
            <textarea class="w-full px-2 py-2 text-gray-700 bg-gray-50 rounded" id="detail" name="detail" required=""></textarea> 
        </div>
        <div class="mt-2">
            <label class="block text-md text-gray-600" for="partner">Mitra</label>
            
            <select name="partner" id="partner" class="w-full px-2 py-2 text-gray-700 bg-gray-50 rounded">
                <option value="">- tidak ada-</option>
                <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($partner->id); ?>"><?php echo e($partner->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="inline-block mt-2 w-1/2 pr-1">
            <label class="block text-md text-gray-600" for="price">Harga</label>
            <input class="w-full px-2 py-2 text-gray-700 bg-gray-50 rounded" id="price" name="price" type="text" required="">
        </div>
        <div class="inline-block mt-2 -mx-1 pl-1 w-1/2">
            <label class="block text-md text-gray-600" for="amount">Jumlah (dalam skala Kg)</label>
            <input class="w-full px-2 py-2 text-gray-700 bg-gray-50 rounded" id="amount" name="amount" type="text" required="" >
        </div>
        <div class="inline-block mt-2 -mx-1 pl-1 w-1/2">
            <label class="block text-md text-gray-600" for="type">Jumlah</label>
            <input class="px-2 py-2" id="type" name="type" type="radio" required="" value="pengeluaran">&nbsp; Pengeluaran &nbsp;
            <input class="px-2 py-2" id="type" name="type" type="radio" required="" value="pemasukan">&nbsp; Pemasukan
        </div>
        <br>
        <div class="inline-block mt-2 -mx-1 pl-1 w-1/2">
            <label class="block text-md text-gray-600" for="image">Gambar</label>
            <input type="file" name="image" class="w-full px-2 py-2 text-gray-700 bg-gray-50 rounded">
        </div>
        
        <div class="mt-6">
            <button class="w-full px-4 py-1 text-white font-light tracking-wider bg-green-500 rounded" type="submit">Tambahkan</button>
        </div>
    </form>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH E:\~GITHUB\kebonkoeh.id\resources\views/owner/add-keuangan.blade.php ENDPATH**/ ?>